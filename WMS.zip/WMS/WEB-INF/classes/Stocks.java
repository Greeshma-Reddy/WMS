package CT;
import databaseconnection.*;
import java.sql.*;

public class Stocks
{
	
	public static int add(String code, String name, String ptype, int c) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into stocks values (?,?,?,?)");
		ps.setString(1,code);
		ps.setString(2,name);
		ps.setString(3,ptype);
		ps.setInt(4,c);
		int res=ps.executeUpdate();	
			
		return res;
	}

	//
	public static ResultSet get()throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from stocks";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}


	public static int update(String pid, int c) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("update stocks set aviailable=aviailable+"+c+" where pid='"+pid+"'");
		int res=ps.executeUpdate();	
			
		return res;
	}

	public static int deduct(String pid, int c) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("update stocks set aviailable=aviailable-"+c+" where pid='"+pid+"'");
		int res=ps.executeUpdate();	
			
		return res;
	}

}
