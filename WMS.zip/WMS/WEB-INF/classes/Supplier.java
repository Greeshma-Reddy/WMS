package CT;
import databaseconnection.*;
import java.sql.*;

public class Supplier
{
	
	
	public static String[] login(String uid, String pwd)throws Exception
	{
		String[] res={"non","non"};
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
			
		String sss1 = "select * from store_manager where email='"+uid+"' && password='"+pwd+"' ";

		ResultSet rs1=st1.executeQuery(sss1);
		if(rs1.next())
		{
			res[0]=rs1.getString("storeid");
				res[1]=rs1.getString("name");


			
		}
		return res;

	}


}
