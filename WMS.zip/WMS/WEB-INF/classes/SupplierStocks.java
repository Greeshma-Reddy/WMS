package CT;
import databaseconnection.*;
import java.sql.*;

public class SupplierStocks
{
	public static int insert(String store, String code, String name, String ptype, String mrp, int s )throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into stores_stock values (?,?,?,?,?,?)");
		ps.setString(1,store);
		ps.setString(2,code);
		ps.setString(3,name);
		ps.setString(4,ptype);

		ps.setString(5,mrp);
		ps.setInt(6,s);;
		int res=ps.executeUpdate();	
			
		return res;
	}



	public static int update(String pid, int c, String store) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("update stores_stock set available=available+"+c+" where pid='"+pid+"' and storeid='"+store+"' ");
		int res=ps.executeUpdate();	
			
		return res;
	}

	//
	public static ResultSet get(String store)throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from stores_stock where storeid='"+store+"'";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}


	public static int deduct(String pid, int c, String store) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("update stores_stock set available=available-"+c+" where pid='"+pid+"' and storeid='"+store+"' ");
		int res=ps.executeUpdate();	
			
		return res;
	}

}
