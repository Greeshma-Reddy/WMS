package CT;
import databaseconnection.*;
import java.sql.*;

public class RetailerStock
{
	public static int insert(String store, String code, String name, String ptype, String mrp, int s, String email) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into retailer_stock values (?,?,?,?,?,?,?)");
		ps.setString(1,store);

		ps.setString(2,code);
		ps.setString(3,name);
		ps.setString(4,ptype);

		ps.setString(5,mrp);
		ps.setInt(6,s);
		ps.setString(7,email);
		int res=ps.executeUpdate();	
			
		return res;
	}



	public static int update(String pid, int c, String email) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("update retailer_stock set available=available+"+c+" where pid='"+pid+"' and retailer='"+email+"' ");
		int res=ps.executeUpdate();	
			
		return res;
	}

	//
	public static ResultSet get(String email)throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from retailer_stock where retailer='"+email+"'";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}


}
