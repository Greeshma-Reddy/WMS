package CT;
import databaseconnection.*;
import java.sql.*;


public class Admin
{
	
	public static boolean login(String uid, String pwd)
	{
		boolean res=false;
		if(uid.equals("admin")&&pwd.equals("admin")){
		res=true;
		}

 		
 			
		return res;
	}

	

	public static int addSupplier(String mid, String name, String email, String ph, String addr, String pwd, String store)throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into store_manager values (?,?,?,?,?,?,?)");
		ps.setString(1,mid);
		ps.setString(2,name);
		ps.setString(3,email);
		ps.setString(4,ph);
		ps.setString(5,addr);
		ps.setString(6,pwd);
		ps.setString(7,store);

		int res=ps.executeUpdate();	


 		
 			
		return res;
	}

}
