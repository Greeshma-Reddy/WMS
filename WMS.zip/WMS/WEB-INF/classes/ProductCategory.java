package CT;
import databaseconnection.*;
import java.sql.*;

public class ProductCategory
{
	
	public static int add(String name)throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into category values (?)");
		ps.setString(1,name);
		int res=ps.executeUpdate();	


 			
		return res;
	}

	
	public static ResultSet get()throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from category";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}


}
