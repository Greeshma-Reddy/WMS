/*
SQLyog Community v11.52 (32 bit)
MySQL - 5.5.30 : Database - wms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`wms` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `wms`;

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `ptype` varchar(100) NOT NULL,
  PRIMARY KEY (`ptype`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `prodcode` varchar(100) DEFAULT NULL,
  `ptype` varchar(100) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `mrp` varchar(10) DEFAULT NULL,
  `company` varchar(199) DEFAULT NULL,
  `rating` double DEFAULT '3',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `purchase` */

DROP TABLE IF EXISTS `purchase`;

CREATE TABLE `purchase` (
  `retailer` varchar(100) DEFAULT NULL,
  `pid` varchar(100) DEFAULT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `mrp` varchar(100) DEFAULT NULL,
  `how` varchar(100) DEFAULT NULL,
  `tcost` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `request` */

DROP TABLE IF EXISTS `request`;

CREATE TABLE `request` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `storeid` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `data` varchar(500) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'new',
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `retailer_stock` */

DROP TABLE IF EXISTS `retailer_stock`;

CREATE TABLE `retailer_stock` (
  `storeid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `mrp` varchar(10) DEFAULT NULL,
  `available` int(11) DEFAULT NULL,
  `retailer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`storeid`,`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `stocks` */

DROP TABLE IF EXISTS `stocks`;

CREATE TABLE `stocks` (
  `pid` int(11) NOT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `aviailable` int(11) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `store` */

DROP TABLE IF EXISTS `store`;

CREATE TABLE `store` (
  `storeid` varchar(100) NOT NULL DEFAULT '',
  `area` varchar(100) NOT NULL,
  PRIMARY KEY (`area`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `store_manager` */

DROP TABLE IF EXISTS `store_manager`;

CREATE TABLE `store_manager` (
  `mid` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `storeid` varchar(20) NOT NULL,
  PRIMARY KEY (`storeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `store_retailer` */

DROP TABLE IF EXISTS `store_retailer`;

CREATE TABLE `store_retailer` (
  `mid` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `storeid` varchar(20) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `stores_stock` */

DROP TABLE IF EXISTS `stores_stock`;

CREATE TABLE `stores_stock` (
  `storeid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `mrp` varchar(10) DEFAULT NULL,
  `available` int(11) DEFAULT NULL,
  PRIMARY KEY (`storeid`,`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
