package CT;
import databaseconnection.*;
import java.sql.*;

public class Retailer
{
	
	public static int signup(String mid, String name, String email, String ph, String addr, String pwd, String store) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into store_Retailer values (?,?,?,?,?,?,?)");
		ps.setString(1,mid);
		ps.setString(2,name);
		ps.setString(3,email);
		ps.setString(4,ph);
		ps.setString(5,addr);
		ps.setString(6,pwd);
		ps.setString(7,store);

		int res=ps.executeUpdate();	


 		
 			
		return res;
	}

	
	public static String[] login(String uid, String pwd)throws Exception
	{
		String[] res={"non","non"};
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
			
		String sss1 = "select * from store_Retailer where email='"+uid+"' && password='"+pwd+"' ";

		ResultSet rs1=st1.executeQuery(sss1);
		if(rs1.next())
		{
			res[0]=rs1.getString("storeid");
				res[1]=rs1.getString("name");

			
		}
		return res;

	}


}
