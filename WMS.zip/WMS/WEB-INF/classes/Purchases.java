package CT;
import databaseconnection.*;
import java.sql.*;

public class Purchases
{
	public static int insert(String email, String pid, String name, String mrp, String v1,  String v2,  String date,  String store) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();
		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into purchase values (?,?,?,?,?,?,?,?)");
		ps.setString(1,email);

		ps.setString(2,pid);
		ps.setString(3, name);
		ps.setString(4,mrp);

		ps.setString(5,v1);
		ps.setString(6,v2);
		ps.setString(7,date);
		ps.setString(8,store);

		int res=ps.executeUpdate();	
		return res;
	}



	//
	public static ResultSet get(String email)throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from purchase where retailer='"+email+"'";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}	//
	public static ResultSet getForStore(String store)throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from purchase where store='"+store+"'";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}


}
