package CT;
import databaseconnection.*;
import java.sql.*;

public class Products
{
	
	public static int add(String code, String ptype, String name, String mrp, String company, String rating) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into products values (?,?,?,?,?,?)");
		ps.setString(1,code);
		ps.setString(2,ptype);
		ps.setString(3,name);
		ps.setString(4,mrp);
		ps.setString(5,company);
		ps.setString(6,rating);
		int res=ps.executeUpdate();	
			
		return res;
	}

	
	public static ResultSet get()throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from products";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}

	public static ResultSet search(String keys)throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from products where name like '%"+keys+"%' ";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}



}
