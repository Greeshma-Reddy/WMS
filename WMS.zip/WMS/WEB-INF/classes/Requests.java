package CT;
import databaseconnection.*;
import java.sql.*;

public class Requests
{
	
	public static int add(String sid, String email, String prod) throws Exception
	{
		Connection ccc=databasecon.getconnection();
		Statement ss = ccc.createStatement();

		PreparedStatement ps=null;

		ps=ccc.prepareStatement("insert into request(storeid, email, data) values (?,?,?)");
		ps.setString(1,sid);
		ps.setString(2,email);
		ps.setString(3,prod);
		int res=ps.executeUpdate();	
			
		return res;
	}

	
	public static ResultSet get()throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		String sss1 = "select * from request where status='new'";
		ResultSet rs1=st1.executeQuery(sss1);
		return rs1;

	}	
	public static void update(String id)throws Exception
	{
		Connection con1 = databasecon.getconnection();
		Statement st1 = con1.createStatement();
		
		String sss1 = "update request set status='Noted' where sno='"+id+"'";

		st1.executeUpdate(sss1);

	}

	



}
